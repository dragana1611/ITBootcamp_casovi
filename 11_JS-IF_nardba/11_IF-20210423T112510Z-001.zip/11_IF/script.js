console.log("IF - Naredba grananja");

let a = 70;
let b = 10;

if(a < b){
    console.log("a je manje od b");
}

console.log("If je završen");